﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using Project.Models;
using System.Security.Cryptography;
using System.Text;

namespace Project.Controllers
{
    public class ProjectController : Controller
    {
        private BudgetEntities db = new BudgetEntities();
        // GET: Project
        [HttpPost]
        public ActionResult Login(string Usernames,string Password)
        {
            var hashedPassword = ComputerHashing(Password);
            Models.User User = db.Users.Where(zz => zz.Username == Usernames && zz.Password == hashedPassword).FirstOrDefault();

            if(User != null)
            {
              
            }
            return View();
        }
        string ComputerHashing(string Rawdata)
        {   
            //Create Hasing 
            using (SHA256 SHA256Hash = SHA256.Create())
            {
                //ComputeHash -  returns byters as a Array
                byte[] bytes = SHA256Hash.ComputeHash(Encoding.UTF8.GetBytes(Rawdata));

                //Convert byte to array to a string
                StringBuilder builder = new StringBuilder();
                for(int i = 0;i < bytes.Length;i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
        public ActionResult BudgetLimits()
        {
            return View();
        }
        public ActionResult SpendingTransaction()
        {
            return View();
        }
        public ActionResult IncomeTransaction()
        {
            return View();
        }
        public ActionResult InvestmentCalculator()
        {
            return View();
        }
        public ActionResult MonthlySpending()
        {
            return View();
        }
        public ActionResult Register()
        {
            return View();
        }
        public ActionResult ReportNetworth()
        {
            return View();
        }
        public ActionResult ReportSavings()
        {
            return View();
        }
        public ActionResult ForgotPassword()
        {
            return View();
        }
        public ActionResult Home()
        {
            return View();
        }
        public ActionResult UpdateUser()
        {
            return View();
        }
        public ActionResult InvestmentMade()
        {
            return View();
        }
    }
}